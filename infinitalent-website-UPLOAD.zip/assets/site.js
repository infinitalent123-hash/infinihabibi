(function(){
var d=document,b=d.body;
var mb=d.getElementById('mb'),nv=d.getElementById('nv');
if(mb&&nv){mb.addEventListener('click',function(){var o=nv.classList.toggle('on');mb.setAttribute('aria-expanded',o?'true':'false');});}
var r=d.querySelectorAll('.rv');
if('IntersectionObserver' in window){var io=new IntersectionObserver(function(es){es.forEach(function(e){if(e.isIntersecting){e.target.classList.add('in');io.unobserve(e.target);}});},{threshold:.1});r.forEach(function(x){io.observe(x);});}
else{r.forEach(function(x){x.classList.add('in');});}
var t0=Date.now();
d.querySelectorAll('form[data-form]').forEach(function(f){
 var st=f.querySelector('.st');
 f.addEventListener('submit',function(ev){
  f.querySelector('[name=t]').value=String(Math.floor((Date.now()-t0)/1000));
  if(!window.fetch||!window.FormData){return;}
  ev.preventDefault();
  if(!f.checkValidity()){f.reportValidity();st.className='w st err';st.textContent='Please correct the highlighted fields.';return;}
  var btn=f.querySelector('button');btn.disabled=true;st.className='w st';st.textContent='Sending...';
  var ac=window.AbortController?new AbortController():null;var to=setTimeout(function(){if(ac)ac.abort();},15000);
  fetch(f.action,{method:'POST',body:new FormData(f),headers:{'X-Requested-With':'fetch'},signal:ac?ac.signal:undefined})
  .then(function(x){return x.json().then(function(j){return {ok:x.ok,j:j};});})
  .then(function(o){if(o.ok&&o.j.ok){f.reset();st.className='w st ok';st.textContent='Thank you. We have received your details and will contact you shortly.';}else{throw new Error(o.j&&o.j.error||'fail');}})
  .catch(function(e){st.className='w st err';st.textContent='Sorry, we could not send this. Please call 7892273165 or email jobs@infini-talent.com.';})
  .then(function(){clearTimeout(to);btn.disabled=false;});
 });
});
})();
