<?php
// Infinitalent form handler. Needs PHP 7.4+ with mail() enabled (default on cPanel).
header('X-Content-Type-Options: nosniff');
$TO = 'jobs@infini-talent.com';
$FROM = 'noreply@infinitalentconsult.com';
$ajax = isset($_SERVER['HTTP_X_REQUESTED_WITH']);
function out($ok, $err = '', $code = 200) {
  global $ajax;
  if ($ajax) { http_response_code($code); header('Content-Type: application/json'); echo json_encode(['ok' => $ok, 'error' => $err]); exit; }
  header('Location: /contact/' . ($ok ? '?sent=1' : '?error=1')); exit;
}
if ($_SERVER['REQUEST_METHOD'] !== 'POST') out(false, 'method', 405);
$host = parse_url($_SERVER['HTTP_ORIGIN'] ?? ($_SERVER['HTTP_REFERER'] ?? ''), PHP_URL_HOST);
if ($host && !preg_match('/(^|\.)infinitalentconsult\.com$/i', $host)) out(false, 'origin', 403);
if (!empty($_POST['website'])) out(true);                       // honeypot: pretend success
if ((int)($_POST['t'] ?? 0) < 3) out(false, 'too fast', 400);   // bots submit instantly
// Rate limit: 5 submissions per IP per hour
$ip = $_SERVER['REMOTE_ADDR'] ?? 'x';
$rl = sys_get_temp_dir() . '/icpl_rl_' . md5($ip);
$hits = array_filter(is_file($rl) ? (array)json_decode(file_get_contents($rl), true) : [], function ($x) { return $x > time() - 3600; });
if (count($hits) >= 5) out(false, 'rate', 429);
$hits[] = time(); @file_put_contents($rl, json_encode(array_values($hits)), LOCK_EX);
function clean($v, $max) { $v = trim(preg_replace('/[\r\n\t]+/', ' ', (string)$v)); return mb_substr($v, 0, $max); }
$name = clean($_POST['name'] ?? '', 80); $email = clean($_POST['email'] ?? '', 120); $phone = clean($_POST['phone'] ?? '', 15);
if ($name === '' || !filter_var($email, FILTER_VALIDATE_EMAIL) || !preg_match('/^[0-9+ ]{10,15}$/', $phone)) out(false, 'invalid', 422);
$fields = ['type' => 40, 'company' => 120, 'city' => 60, 'service' => 100, 'qualification' => 100, 'profile' => 200];
$lines = ["Name: $name", "Email: $email", "Phone: $phone"];
foreach ($fields as $k => $m) { $v = clean($_POST[$k] ?? '', $m); if ($v !== '') $lines[] = ucfirst($k) . ": $v"; }
$msg = trim(mb_substr(strip_tags((string)($_POST['message'] ?? '')), 0, 1500));
$lines[] = "Message:\n$msg"; $lines[] = "IP: $ip   Time: " . date('c');
$body = implode("\n", $lines);
$subject = 'Website enquiry: ' . clean($_POST['type'] ?? 'contact', 40) . ' - ' . $name;
$headers = "From: Infinitalent Website <$FROM>\r\nReply-To: $email\r\nContent-Type: text/plain; charset=UTF-8\r\n";
$sent = @mail($TO, '=?UTF-8?B?' . base64_encode($subject) . '?=', $body, $headers);
@file_put_contents(__DIR__ . '/_data/submissions.log', $body . "\nMAIL:" . ($sent ? 'sent' : 'FAILED') . "\n----\n", FILE_APPEND | LOCK_EX);
if (!$sent) out(false, 'mail', 500);
out(true);
